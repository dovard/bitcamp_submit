import os
import cv2
import sorrt

#==========================트레이닝 데이터 만들기
#트레이닝 데이터 폴더 생성하고 - > 그 내부에 0-12 폴더 생성



image = cv2.imread("19.png") #하나의 이미지에 대해서
chars = sorrt.extract_chars(image) #색상별로 숫자 이미지를 추출한 다음에 char라는 변수에 담기
# print(image.shape)

for char in chars:
    cv2.imshow('Image', char[1])
    input = cv2.waitKey(0) # 일단 보여주기
    resized = cv2.resize(char[1], (20,20)) #사이즈 바꿔서 저장

    if input >= 48 and input <=57: #사용자가 어떤 숫자인지 labeling하기 위한 if문  -> 0-9까지 이미지 폴더에 저장시킴
        name = str(input -48)
        file_count = len(next(os.walk('./training_data/' +name+'/'))[2])
        cv2.imwrite('./training_data/'+str(input - 48) +'/' +
                    str(file_count + 1 )+ '.png', resized)
    elif input == ord('a') or input == ord('b') or input == ord('c'):   #+:a:10 , -:b:11, *:c:12 로 입력해서 저장
        name = str(input - ord('a') + 10)
        file_count = len(next(os.walk('./training_data/' +name +'/'))[2])
        cv2.imwrite('./training_data/' + name + '/' +
                    str(file_count + 1) + '.png', resized)





