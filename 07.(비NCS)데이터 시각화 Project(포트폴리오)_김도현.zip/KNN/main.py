import numpy as np
import cv2


BLUE = 0
GREEN = 1
RED = 2

#=============각 색상별로 이미지 색통일
def get_chars(image, color):


    other_1 = (color + 1) % 3
    other_2 = (color + 2) % 3

    C=image[:, :, other_1] == 255 #G
    image[C] = [0,0,0]

    C=image[:,:,other_2] == 255 #R
    image[C] = [0,0,0]
    
    C=image[:, :, color] < 170   #선택한 color 값이 170보다 작으면(G+R) 0,0,0:검은색으로 바꿈
    image[C] = [0,0,0]
    
    C=image[:, :, color]  !=0  #하얀색 (ONLY BLUE)
    image[C] = [255,255,255] 

    return image

#각 사이즈가 다르니까 ->이미지 사이즈 20x20 통일
def resize20(image):
    resized = cv2.resize(image, (20,20))
    return resized.reshape(-1, 400).astype(np.float32)
    

