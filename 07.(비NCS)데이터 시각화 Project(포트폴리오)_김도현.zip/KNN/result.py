import runnnn
import sorrt
import main
import utils
from PIL import Image
import os

PATH = "script/numbers"

li = os.listdir(PATH)
for i, Q in enumerate(li):
    answer_string = runnnn.get_result(f'{PATH}/{Q}')
    print(f"========================={i+1} Q=========================\n")
    print('Q: '+ answer_string)
    answer_string = utils.remove_first_0(answer_string)
    answer = str(eval(answer_string))
    print('A: ' + answer)   
    print('=========================NEXT=========================\n')
