import os
import cv2
import numpy as np

file_names = list(range(0,13)) #0-9,10,11,12 폴더에서 파일 불러오기
train = [] #train 데이터를 채우고
train_labels = [] #각각 데이터가 어떤 레이블을 가지는지 설정
for file_name in file_names:
    path = './training_data/' +str(file_name) + '/' # 각각 파일 불러오기
    file_count = len(next(os.walk(path))[2]) # os.walk함수: 해당 이미지 파일이 몇개인지 확인/읽기
    for i in range(1, file_count + 1):
        img = cv2.imread(path +str(i) +'.png') #파일 수에 따라 1,2,3.....png 로 저장
        gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
        train.append(gray) #train list에 넣겠다
        train_labels.append(file_name) 


x=np.array(train)
train = x[:,:].reshape(-1, 400).astype(np.float32)  #학습시키려면 20x20을 reshape
train_labels = np.array(train_labels)[:, np.newaxis] #




# print(train.shape)
# print(train_labels)
# Rnp.savez("trained.npz", train=train, train_labels=train_labels)   #train정보를 npz파일 형태로 저장




