import cv2
import test
import main

#======왼쪽부터 단어별로 이미지 추출==========


def extract_chars(image):
    chars = []
    colors = [main.BLUE, main.GREEN, main.RED]
    for color in colors:
        image_from_one_color = main.get_chars(image.copy(), color)
        image_gray = cv2.cvtColor(image_from_one_color, cv2.COLOR_BGR2GRAY)
        ret, thresh = cv2.threshold(image_gray, 127, 255, 0)
        #RETR_CWTERNAL 옵션으로 숫자의 외각을 기준으로 분리
        contours, _ = cv2.findContours(thresh, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)

        for contour in contours : 
            #추출된 이미지 크기가 50 이상인 경우만 -> 실제 문자 데이터인 것으로 파악
            area = cv2.contourArea(contour)
            if area > 50 :
                x, y, width, height = cv2.boundingRect(contour)
                roi = image_gray[y:y + height, x:x + width] #숫자에 해당하는 부분만 뽑기
                chars.append((x,roi))

    #추출한 이미지를 x축 기준으로 정렬 -> 사각형으로 컨투어!->정렬하기            
    chars = sorted(chars, key=lambda char : char[0])#x축기준
    return chars
    
