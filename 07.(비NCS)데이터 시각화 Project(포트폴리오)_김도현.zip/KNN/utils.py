#수식 정제

import re

def remove_first_0(string):
    temp = []
    for i in string:
        if i=='+' or i =='-' or i == '*': 
            temp.append(i)
    split = re.split('\*|\+|-', string) #부호를 기준으로 숫자 구분 (0000) + (0000)
    i=0
    temp_count = 0
    result = ""
    for a in split : 
        a = a.lstrip('0') #숫자 앞이 0으로 시작하는 경우 제거
        if a =='':
            a = '0'
        result += a
        if i <len(split) -1:
            result += temp[temp_count]
            temp_count = temp_count +1

        i = i+1
    return result