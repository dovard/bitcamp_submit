import cv2
import main

image = cv2.imread('19.png', cv2.IMREAD_COLOR)
blue = main.get_chars(image.copy(), main.BLUE) #main에서 blue 추출한 부분만 blue에 담기
green = main.get_chars(image.copy(), main.GREEN)
red = main.get_chars(image.copy(), main.RED)

# cv2.imshow('Image Gray', blue) #title, 위에서 받은 blue
# cv2.waitKey(0)
# cv2.imshow('IMAGE Gray', green)
# cv2.waitKey(0)
# cv2.imshow('Image Gray', red)
# cv2.waitKey(0)