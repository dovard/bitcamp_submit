import numpy as np
import cv2
import main
import sorrt

FILE_NAME = "trained.npz" #저장된 데이터 불러와서 예시 돌리기

with np.load(FILE_NAME) as data:
    train = data['train']
    train_labels = data['train_labels']

    
knn=cv2.ml.KNearest_create()
knn.train(train, cv2.ml.ROW_SAMPLE, train_labels)


def check(test, train, train_labels): #test파일을 줬을때 knn.findNearest함수를 불러와서 test와 가장 가까운(k=1) train_data를 찾아서 -> 그 data의 result(label)을 출력할 수 있는 함수 #k=1이어도괜찮은 이유: 주어진 숫자의 글씨체, 크기가 다 같아서 한개로만 비교해도 분류 가능
    #가장 가까운 K개의 글자를 찾아 어떤숫자에 해당하는지 찾기 
    ret, result, neighbours, dist = knn.findNearest(test, k=1)
    return result

def get_result(file_name): #특정한 이미지 정보가 들어왔을때 거기에 맞는 실제 수집정보를 불러오기
    image = cv2.imread(file_name) #file_name 파일이 들어왔을 때 
    chars = sorrt.extract_chars(image) #그 파일을 왼쪽에서부터 차례대로  char에 담기
    result_string = "" #for 문으로 문자열 형태 만들기
    for char in chars:
        matched = check(main.resize20(char[1]), train, train_labels) #resize  모든 이미지를 400으로 늘리고 
        if matched < 10: #숫자면
            result_string += str(int(matched))
            continue
        if matched == 10: #부호면
            matched = '+'
        elif matched == 11:
            matched = '-'
        elif matched == 12:
            matched = '*'
        result_string += matched
    return result_string


