import cv2
import numpy as np


kernel = np.ones((5, 15), np.uint8)


img = cv2.imread('img/car/00.jpg')

gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
blur = cv2.blur(gray, (5, 5))
sobel = cv2.Sobel(blur, -1, 1, 0, ksize=3)
th_img = cv2.threshold(sobel, 120, 255, cv2.THRESH_BINARY)[1]
morph = cv2.morphologyEx(th_img, cv2.MORPH_CLOSE, kernel, iterations=2)
cv2.imshow('img', img)
cv2.waitKey(0)
cv2.imshow('img', gray)
cv2.waitKey(0)
cv2.imshow('img', blur)
cv2.waitKey(0)
cv2.imshow('img', sobel)
cv2.waitKey(0)
cv2.imshow('img', th_img)
cv2.waitKey(0)
cv2.imshow('img', morph)
cv2.waitKey(0)
