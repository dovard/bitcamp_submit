from prepro import *
import matplotlib.pyplot as plt
# car_no = int(input('Car number(0~1): '))
for x in range(7):
    i = '%02d' % x
    try:
        image, morph = preprocessing(i)
        if image is None:
            Exception("Read Error")

        candidates = find_candidates(morph)
        for candidate in candidates:
            pts = np.int32(cv2.boxPoints(candidate))
            cv2.polylines(image, [pts], True, (0, 255, 0), 2)

        if not candidates:
            print("None Plate Area")

        plt.imshow(cv2.cvtColor(image, cv2.COLOR_BGR2RGB))
        plt.show()
    except:
        pass
