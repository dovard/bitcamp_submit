import sys
from konlpy import init_jvm
from konlpy.tag import Kkma, Hannanum,Twitter
from konlpy.utils import pprint
from wordcloud import WordCloud, STOPWORDS
import pandas as pd
import numpy as np
import platform
from PIL import Image
import os
import matplotlib.pyplot as plt
import platform
from konlpy.corpus import kobill
import random
from nltk.downloader import Downloader
from nltk.tokenize import word_tokenize
import nltk
from sklearn.feature_extraction.text import CountVectorizer
import scipy as sp
from bs4 import BeautifulSoup
import requests
import urllib
import time
from tqdm import tqdm_notebook, tqdm

# print(os.getcwd())

'''
C:\ProgramData\Anaconda3\envs\pythonsm1\python.exe C:/Users/yuhwan/PycharmProjects/pythonsm1/nlp_s/nlp_1.py
'''
java_home = os.environ['JAVA_HOME']

kkma = Kkma()

# pprint(kkma.sentences('한국어 분석을 시작합니다 재미있어요~~'))
#['한국어 분석을 시작합니다', '재미있어요~~']

# pprint(kkma.nouns('한국어 분석을 시작합니다 재미있어요~~'))
#['한국어', '분석']

# pprint(kkma.pos('한국어 분석을 시작합니다 재미있어요~~'))
'''
[('한국어', 'NNG'),
 ('분석', 'NNG'),
 ('을', 'JKO'),
 ('시작하', 'VV'),
 ('ㅂ니다', 'EFN'),
 ('재미있', 'VA'),
 ('어요', 'EFN'),
 ('~~', 'SW')]
'''

hannanum = Hannanum()

# pprint(hannanum.nouns('한국어 분석을 시작합니다 재미있어요~~'))
# ['한국어', '분석', '시작']

# pprint(hannanum.morphs('한국어 분석을 시작합니다 재미있어요~~'))
# ['한국어', '분석', '을', '시작', '하', 'ㅂ니다', '재미있', '어요', '~~']

# pprint(hannanum.pos('한국어 분석을 시작합니다 재미있어요~~'))
'''
[('한국어', 'N'),
 ('분석', 'N'),
 ('을', 'J'),
 ('시작', 'N'),
 ('하', 'X'),
 ('ㅂ니다', 'E'),
 ('재미있', 'P'),
 ('어요', 'E'),
 ('~~', 'S')]
'''

t = Twitter()

# pprint(t.nouns('한국어 분석을 시작합니다 재미있어요~~'))
'''
에러같은 에러같지 않은 에러인듯 아닌듯
C:\ProgramData\Anaconda3\envs\pythonsm1\lib\site-packages\konlpy\tag\_okt.py:16: UserWarning: "Twitter" has changed to "Okt" since KoNLPy v0.4.5.
  warn('"Twitter" has changed to "Okt" since KoNLPy v0.4.5.')
['한국어', '분석', '시작']
'''

# pprint(t.morphs('한국어 분석을 시작합니다 재미있어요~~'))
'''
['한국어', '분석', '을', '시작', '합니다', '재미있어요', '~~']
'''

# pprint(t.pos('한국어 분석을 시작합니다 재미있어요~~'))
'''
[('한국어', 'Noun'),
 ('분석', 'Noun'),
 ('을', 'Josa'),
 ('시작', 'Noun'),
 ('합니다', 'Verb'),
 ('재미있어요', 'Adjective'),
 ('~~', 'Punctuation')]

'''
''' alice '''
text = open('C:\\Users\yuhwan\PycharmProjects\pythonsm1\data\\09. alice.txt').read()
alice_mask = np.array(Image.open('C:\\Users\yuhwan\PycharmProjects\pythonsm1\data\\09. alice_mask.png'))

stopwords = set(STOPWORDS)
stopwords.add("said")



path =  "c:/Windows/Fonts/malgun.ttf"
from matplotlib import font_manager, rc
if platform.system() =='Darwin':
    rc('font',family ='AppleGothic')
elif platform.system() == 'Windows':
    font_name = font_manager.FontProperties(fname=path).get_name()
    rc('font',family=font_name)
else:
    print('Unknown system...sorry~~~')

# plt.figure(figsize=(8,8))
# plt.imshow(alice_mask,cmap=plt.cm.gray, interpolation='bilinear')
# plt.axis('off')
# plt.show()
wc = WordCloud(background_color='white', max_words=2000, mask=alice_mask,stopwords=stopwords)
wc = wc.generate(text)
wc.words_
plt.figure(figsize=(12,12))
plt.imshow(wc,interpolation="bilinear")
plt.axis('off')
plt.show()

'''22    '''
text = open('C:\\Users\yuhwan\PycharmProjects\pythonsm1\data\\09. a_new_hope.txt').read()
text = text.replace('HAN','han')
text = text.replace("LUKE'S",'luke')

mask = np.array(Image.open('C:\\Users\yuhwan\PycharmProjects\pythonsm1\data\\09. stormtrooper_mask.png'))
stopwords = set(STOPWORDS)
stopwords.add("int")
stopwords.add('ext')
wc = WordCloud(max_words=1000, mask=mask, stopwords=stopwords, margin=10, random_state=1).generate(text)
default_colors = wc.to_array()

def gray_color_func(word, font_size, position,orientation,random_state=None,**kwargs):
    return pprint('hsi(0 , 0%%, %d%%)'%random.randint(60,100))

plt.figure(figsize=(12,12))
plt.imshow(wc.recolor(color_func=gray_color_func, random_state=3),interpolation="bilinear")
plt.axis('off')
plt.show()


files_ko = kobill.fileids()
doc_ko = kobill.open('1809890.txt').read()
tokens_ko = t.nouns(doc_ko)
tokens_ko

ko = nltk.Text(tokens_ko, name='대한민국 국회 의안 제 1809890호')
print(len(ko.tokens))
print(len(set(ko.tokens)))
pprint(ko.vocab())

'''
'hsi(0 , 0%, 93%)'
'hsi(0 , 0%, 89%)'
'hsi(0 , 0%, 76%)'
'hsi(0 , 0%, 63%)'
'hsi(0 , 0%, 81%)'
'hsi(0 , 0%, 97%)'
'hsi(0 , 0%, 72%)'
'hsi(0 , 0%, 64%)'
'hsi(0 , 0%, 70%)'
'hsi(0 , 0%, 96%)'
'hsi(0 , 0%, 64%)'
'hsi(0 , 0%, 62%)'
'hsi(0 , 0%, 88%)'
'hsi(0 , 0%, 76%)'
'hsi(0 , 0%, 79%)'
'hsi(0 , 0%, 78%)'
'hsi(0 , 0%, 96%)'
'hsi(0 , 0%, 99%)'
'hsi(0 , 0%, 62%)'
'hsi(0 , 0%, 92%)'
'hsi(0 , 0%, 62%)'
'hsi(0 , 0%, 60%)'
'hsi(0 , 0%, 96%)'
'hsi(0 , 0%, 80%)'
'''
''' 37 '''
plt.figure(figsize=(12, 6))
ko.plot(50)
plt.show()

print("초등학겨 count")
pprint(ko.count('초등학교'))

plt.figure(figsize=(12,6))
ko.dispersion_plot(['육아휴직','초등학교','공무원'])  # word offset

pprint(ko.concordance('초등학교'))

nltk.download('stopwords')
nltk.download('punkt')
pprint(ko.collocations())  ## 다운로드 해야함

data = ko.vocab().most_common(150)

wordcloud = WordCloud(font_path='c:/Windows/Fonts/malgun.ttf',relative_scaling=0.2,background_color='white',).generate_from_frequencies(dict(data))
plt.figure(figsize=(12,8))
plt.imshow(wordcloud)
plt.axis("off")
plt.show()


''' Naive Bayes Classifier '''
'''from  nltk.tokenize import word_tokenize
import nltk
'''

train = [('i like you', 'pos'),
         ('i hate you', 'neg'),
         ('you like me', 'neg'),
         ('i like her','pos')]

all_words = set(word.lower() for sentece in train for word in word_tokenize(sentece[0]))
pprint(all_words)
'''
{'hate', 'i', 'like', 'me', 'her', 'you'}
'''
t = [({word:(word in word_tokenize(x[0])) for word in all_words},x[1])for x in train]
print(t)

'''
[({'hate': False,
   'her': False,
   'i': True,
   'like': True,
   'me': False,
   'you': True},
  'pos'),
 ({'hate': True,
   'her': False,
   'i': True,
   'like': False,
   'me': False,
   'you': True},
  'neg'),
 ({'hate': False,
   'her': False,
   'i': False,
   'like': True,
   'me': True,
   'you': True},
  'neg'),
 ({'hate': False,
   'her': True,
   'i': True,
   'like': True,
   'me': False,
   'you': False},
  'pos')]

Process finished with exit code 0

'''


classifier = nltk.NaiveBayesClassifier.train(t)
classifier.show_most_informative_features()

'''
Most Informative Features
                    hate = False             pos : neg    =      1.7 : 1.0
                     her = False             neg : pos    =      1.7 : 1.0
                       i = True              pos : neg    =      1.7 : 1.0
                    like = True              pos : neg    =      1.7 : 1.0
                      me = False             pos : neg    =      1.7 : 1.0
                     you = True              neg : pos    =      1.7 : 1.0
'''

test_sentence = 'i like MeRui'
test_sent_features = {word.lower():(word in word_tokenize(test_sentence.lower())) for word in all_words }
pprint(test_sent_features)
'''
{'hate': False,
 'her': False,
 'i': True,
 'like': True,
 'me': False,
 'you': False}
'''
pprint(classifier.classify(test_sent_features))
''' 'pos' '''

''' Naive Bayes Classifiier 의 이해 - 한글 '''
from konlpy.tag import Twitter
pos_tagger = Twitter()
train = [('메리가 졸아', 'pos'),
         ('고양이도 좋아','pos'),
         ('난 수업이 지루해', 'neg'),
         ('메리는 이쁜 고양이야','pos'),
         ('난 마치고 메이랑 놀거야','pos')]

all_words = set(word.lower() for sentence in train for word in word_tokenize(sentence[0]))


'''
{'고양이도',
 '고양이야',
 '난',
 '놀거야',
 '마치고',
 '메리가',
 '메리는',
 '메이랑',
 '수업이',
 '이쁜',
 '졸아',
 '좋아',
 '지루해'}
'''
#
t = [({word: (word in word_tokenize(x[0])) for word in all_words}, x[1]) for  x in train]
# pprint(t)
classifier = nltk.NaiveBayesClassifier.train(t)
# classifier.show_most_informative_features()
'''
Most Informative Features
                       난 = True              neg : pos    =      2.5 : 1.0
                    고양이도 = False             neg : pos    =      1.1 : 1.0
                    고양이야 = False             neg : pos    =      1.1 : 1.0
                     놀거야 = False             neg : pos    =      1.1 : 1.0
                     마치고 = False             neg : pos    =      1.1 : 1.0
                     메리가 = False             neg : pos    =      1.1 : 1.0
                     메리는 = False             neg : pos    =      1.1 : 1.0
                     메이랑 = False             neg : pos    =      1.1 : 1.0
                      이쁜 = False             neg : pos    =      1.1 : 1.0
                      졸아 = False             neg : pos    =      1.1 : 1.0

Process finished with exit code 0

'''

test_sentence = '난 수업이 마치면 메리랑 놀거야'
test_sent_features = { word.lower():(word in word_tokenize(test_sentence.lower())) for word in all_words}
# pprint(test_sent_features)
'''
{'고양이도': False,
 '고양이야': False,
 '난': True,
 '놀거야': True,
 '마치고': False,
 '메리가': False,
 '메리는': False,
 '메이랑': False,
 '수업이': True,
 '이쁜': False,
 '졸아': False,
 '좋아': False,
 '지루해': False}

Process finished with exit code 0

'''
classifier.classify(test_sent_features)
# pprint(classifier.classify(test_sent_features))
# 'neg'

def tokenize(doc):
    return ['/'.join(t) for t in pos_tagger.pos(doc, norm=True, stem=True)]

train_docs = [(tokenize(row[0]),row[1]) for row in train]
# pprint(train_docs)
'''
[(['메리/Noun', '가/Josa', '졸다/Verb'], 'pos'),
 (['고양이/Noun', '도/Josa', '좋다/Adjective'], 'pos'),
 (['난/Noun', '수업/Noun', '이/Josa', '지루하다/Adjective'], 'neg'),
 (['메리/Noun', '는/Josa', '이쁘다/Adjective', '고양이/Noun', '야/Josa'], 'pos'),
 (['난/Noun', '마치/Noun', '고/Josa', '메이/Noun', '랑/Josa', '놀다/Verb'], 'pos')]
'''

tokens = [t for d in train_docs for t in d[0]]
# pprint(tokens)
'''
['메리/Noun',
 '가/Josa',
 '졸다/Verb',
 '고양이/Noun',
 '도/Josa',
 '좋다/Adjective',
 '난/Noun',
 '수업/Noun',
 '이/Josa',
 '지루하다/Adjective',
 '메리/Noun',
 '는/Josa',
 '이쁘다/Adjective',
 '고양이/Noun',
 '야/Josa',
 '난/Noun',
 '마치/Noun',
 '고/Josa',
 '메이/Noun',
 '랑/Josa',
 '놀다/Verb']

Process finished with exit code 0

'''
def term_exists(doc):
    return {word: (word in set(doc)) for word in tokens}

train_xy = [(term_exists(d),c) for d,c in train_docs]
# pprint(train_xy)
'''
[({'가/Josa': True,
   '고/Josa': False,
   '고양이/Noun': False,
   '난/Noun': False,
   '놀다/Verb': False,
   '는/Josa': False,
   '도/Josa': False,
   '랑/Josa': False,
   '마치/Noun': False,
   '메리/Noun': True,
   '메이/Noun': False,
   '수업/Noun': False,
   '야/Josa': False,
   '이/Josa': False,
   '이쁘다/Adjective': False,
   '졸다/Verb': True,
   '좋다/Adjective': False,
   '지루하다/Adjective': False},
  'pos'),
 ({'가/Josa': False,
   '고/Josa': False,
   '고양이/Noun': True,
   '난/Noun': False,
   '놀다/Verb': False,
   '는/Josa': False,
   '도/Josa': True,
   '랑/Josa': False,
   '마치/Noun': False,
   '메리/Noun': False,
   '메이/Noun': False,
   '수업/Noun': False,
   '야/Josa': False,
   '이/Josa': False,
   '이쁘다/Adjective': False,
   '졸다/Verb': False,
   '좋다/Adjective': True,
   '지루하다/Adjective': False},
  'pos'),
 ({'가/Josa': False,
   '고/Josa': False,
   '고양이/Noun': False,
   '난/Noun': True,
   '놀다/Verb': False,
   '는/Josa': False,
   '도/Josa': False,
   '랑/Josa': False,
   '마치/Noun': False,
   '메리/Noun': False,
   '메이/Noun': False,
   '수업/Noun': True,
   '야/Josa': False,
   '이/Josa': True,
   '이쁘다/Adjective': False,
   '졸다/Verb': False,
   '좋다/Adjective': False,
   '지루하다/Adjective': True},
  'neg'),
 ({'가/Josa': False,
   '고/Josa': False,
   '고양이/Noun': True,
   '난/Noun': False,
   '놀다/Verb': False,
   '는/Josa': True,
   '도/Josa': False,
   '랑/Josa': False,
   '마치/Noun': False,
   '메리/Noun': True,
   '메이/Noun': False,
   '수업/Noun': False,
   '야/Josa': True,
   '이/Josa': False,
   '이쁘다/Adjective': True,
   '졸다/Verb': False,
   '좋다/Adjective': False,
   '지루하다/Adjective': False},
  'pos'),
 ({'가/Josa': False,
   '고/Josa': True,
   '고양이/Noun': False,
   '난/Noun': True,
   '놀다/Verb': True,
   '는/Josa': False,
   '도/Josa': False,
   '랑/Josa': True,
   '마치/Noun': True,
   '메리/Noun': False,
   '메이/Noun': True,
   '수업/Noun': False,
   '야/Josa': False,
   '이/Josa': False,
   '이쁘다/Adjective': False,
   '졸다/Verb': False,
   '좋다/Adjective': False,
   '지루하다/Adjective': False},
  'pos')]
'''

classifier = nltk.NaiveBayesClassifier.train(train_xy)
# classifier.show_most_informative_features()
'''
Most Informative Features                                        대비 몇개인지
                  난/Noun = True              neg : pos    =      2.5 : 1.0
                고양이/Noun = False             neg : pos    =      1.5 : 1.0
                 메리/Noun = False             neg : pos    =      1.5 : 1.0
                  가/Josa = False             neg : pos    =      1.1 : 1.0
                  고/Josa = False             neg : pos    =      1.1 : 1.0
                 놀다/Verb = False             neg : pos    =      1.1 : 1.0
                  는/Josa = False             neg : pos    =      1.1 : 1.0
                  도/Josa = False             neg : pos    =      1.1 : 1.0
                  랑/Josa = False             neg : pos    =      1.1 : 1.0
                 마치/Noun = False             neg : pos    =      1.1 : 1.0

Process finished with exit code 0

'''

test_sentence = [("난 수업이 마치면 메리랑 놀거야")]
test_docs = pos_tagger.pos(test_sentence[0])
# pprint(test_docs)
'''
[('난', 'Noun'),
 ('수업', 'Noun'),
 ('이', 'Josa'),
 ('마치', 'Noun'),
 ('면', 'Josa'),
 ('메리', 'Noun'),
 ('랑', 'Josa'),
 ('놀거야', 'Verb')]
'''
test_sent_features = {word: (word in tokens) for word in test_docs}
# pprint(test_sent_features)
'''
{('난', 'Noun'): False,
 ('놀거야', 'Verb'): False,
 ('랑', 'Josa'): False,
 ('마치', 'Noun'): False,
 ('메리', 'Noun'): False,
 ('면', 'Josa'): False,
 ('수업', 'Noun'): False,
 ('이', 'Josa'): False}
'''

# pprint(classifier.classify(test_sent_features)) # 'pos'

''' 8.7 문장의 유사도 측정'''

vectorizer = CountVectorizer(min_df=1)  # min_df??
contents = ['메리랑 놀러가고 싶지만 바쁜데 어떻하죠?',
            '메리는 공원에서 산책하고 노는 것을 싫어해요',
            '메리는 공원에서 노는 것도 싫어해요. 이상해요',
            '먼 곳으로 여행을 떠나고 싶은데 너무 바빠서 그러질 못하고 있어요']

X = vectorizer.fit_transform(contents)
vectorizer.get_feature_names()
# pprint(vectorizer.get_feature_names())
'''
['것도',
 '것을',
 '곳으로',
 '공원에서',
 '그러질',
 '너무',
 '노는',
 '놀러가고',
 '떠나고',
 '메리는',
 '메리랑',
 '못하고',
 '바빠서',
 '바쁜데',
 '산책하고',
 '싫어해요',
 '싶은데',
 '싶지만',
 '어떻하죠',
 '여행을',
 '이상해요',
 '있어요']
'''

# pprint(X.toarray().transpose()) # 밑 결과 확인 왜인지
'''
array([[0, 0, 1, 0],
       [0, 1, 0, 0],
       [0, 0, 0, 1],
       [0, 1, 1, 0],
       [0, 0, 0, 1],
       [0, 0, 0, 1],
       [0, 1, 1, 0],
       [1, 0, 0, 0],
       [0, 0, 0, 1],
       [0, 1, 1, 0],
       [1, 0, 0, 0],
       [0, 0, 0, 1],
       [0, 0, 0, 1],
       [1, 0, 0, 0],
       [0, 1, 0, 0],
       [0, 1, 1, 0],
       [0, 0, 0, 1],
       [1, 0, 0, 0],
       [1, 0, 0, 0],
       [0, 0, 0, 1],
       [0, 0, 1, 0],
       [0, 0, 0, 1]], dtype=int64)

Process finished with exit code 0

'''

num_samples, num_features = X.shape
# pprint(num_samples) # 4
# pprint(num_features) # 22

new_post = ['메리랑 공원에서 산책하고 놀고 싶어요']
new_post_vec = vectorizer.transform(new_post)
new_post_vec.toarray()
# pprint(new_post_vec.toarray())
'''
array([[0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0]],
      dtype=int64)
'''

def dist_raw(v1,v2):
    delta = v1 - v2
    return sp.linalg.norm(delta.toarray())
#  설정값 같은데?
best_doc = None
best_dist = 65535
best_i = None

for i in range(0, num_samples):
    post_vec = X.getrow(i)
    d = dist_raw(post_vec,new_post_vec)

    print("==Post %i with dist = %.2f     :  %s" % (i,d,contents[i]))

    if d<best_dist:
        best_dist = d
        best_i

contents_tokens = [t.morphs(row) for row in contents]
# pprint(contents_tokens)
'''
[['메리', '랑', '놀러', '가고', '싶지만', '바쁜데', '어떻하죠', '?'],
 ['메리', '는', '공원', '에서', '산책', '하고', '노', '는', '것', '을', '싫어해요'],
 ['메리', '는', '공원', '에서', '노', '는', '것', '도', '싫어해요', '.', '이상해요'],
 ['먼',
  '곳',
  '으로',
  '여행',
  '을',
  '떠나고',
  '싶은데',
  '너무',
  '바빠서',
  '그러질',
  '못',
  '하고',
  '있어요']]

Process finished with exit code 0

'''

contents_for_vectorize = []
for content in contents_tokens:
    sentence = ''
    for word in content:
        sentence = sentence + ' ' + word
    contents_for_vectorize.append(sentence)
contents_for_vectorize
# pprint(contents_for_vectorize)
'''
[' 메리 랑 놀러 가고 싶지만 바쁜데 어떻하죠 ?',
 ' 메리 는 공원 에서 산책 하고 노 는 것 을 싫어해요',
 ' 메리 는 공원 에서 노 는 것 도 싫어해요 . 이상해요',
 ' 먼 곳 으로 여행 을 떠나고 싶은데 너무 바빠서 그러질 못 하고 있어요']
'''
X = vectorizer.fit_transform(contents_for_vectorize)
num_samples, num_features = X.shape
# print(num_samples, num_features)
# (4, 20)

vectorizer.get_feature_names()
# pprint(vectorizer.get_feature_names())
'''
['가고',
 '공원',
 '그러질',
 '너무',
 '놀러',
 '떠나고',
 '메리',
 '바빠서',
 '바쁜데',
 '산책',
 '싫어해요',
 '싶은데',
 '싶지만',
 '어떻하죠',
 '에서',
 '여행',
 '으로',
 '이상해요',
 '있어요',
 '하고']
'''
X.toarray().transpose()
# pprint(X.toarray().transpose())
'''
array([[1, 0, 0, 0],
       [0, 1, 1, 0],
       [0, 0, 0, 1],
       [0, 0, 0, 1],
       [1, 0, 0, 0],
       [0, 0, 0, 1],
       [1, 1, 1, 0],
       [0, 0, 0, 1],
       [1, 0, 0, 0],
       [0, 1, 0, 0],
       [0, 1, 1, 0],
       [0, 0, 0, 1],
       [1, 0, 0, 0],
       [1, 0, 0, 0],
       [0, 1, 1, 0],
       [0, 0, 0, 1],
       [0, 0, 0, 1],
       [0, 0, 1, 0],
       [0, 0, 0, 1],
       [0, 1, 0, 1]], dtype=int64)
'''

new_post = ['메리랑 공원에서 산책하고 놀고 싶어요']
new_post_tokens = [t.morphs(row) for row in new_post]
new_post_for_vectorize = []
for content in new_post_tokens:
    sentence = ''
    for word in content:
        sentence = sentence + ' ' + word

    new_post_for_vectorize.append(sentence)
new_post_for_vectorize
# pprint(new_post_for_vectorize)
# [' 메리 랑 공원 에서 산책 하고 놀고 싶어요']

new_post_vec = vectorizer.transform(new_post_for_vectorize)
# pprint(new_post_vec.toarray())
'''
array([[0, 1, 0, 0, 0, 0, 1, 0, 0, 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1]],
      dtype=int64)
'''


for i in range(0, num_samples):
    post_vec = X.getrow(i)
    d = dist_raw(post_vec,new_post_vec)

    print("==Post %i with dist = %.2f     :  %s" % (i,d,contents[i]))

    if d<best_dist:
        best_dist = d
        best_i = i

# print("Best post is %i,dist = %.2f" %(best_i, best_dist))
# print('-->', new_post)
# print('----->', contents[best_i])
'''
Best post is 1,dist = 1.00
--> ['메리랑 공원에서 산책하고 놀고 싶어요']
-----> 메리는 공원에서 산책하고 노는 것을 싫어해요
'''

for i in range(0, len(contents)):
    print(X.getrow(i).toarray())
print("--------------------")
# print(new_post_vec.toarray())
'''
[[1 0 0 0 1 0 1 0 1 0 0 0 1 1 0 0 0 0 0 0]]
[[0 1 0 0 0 0 1 0 0 1 1 0 0 0 1 0 0 0 0 1]]
[[0 1 0 0 0 0 1 0 0 0 1 0 0 0 1 0 0 1 0 0]]
[[0 0 1 1 0 1 0 1 0 0 0 1 0 0 0 1 1 0 1 1]]
--------------------
[[0 1 0 0 0 0 1 0 0 1 0 0 0 0 1 0 0 0 0 1]]
'''

def dist_norm(v1,v2):
    v1_normalized = v1 / sp.linalg.norm(v1.toarray())
    v2_normalized = v2 / sp.linalg.norm(v2.toarray())

    delta = v1_normalized - v2_normalized

    return sp.linalg.norm(delta.toarray())

best_doc = None
best_dist = 65535
best_i = None

for i in range(0, num_samples):
    post_vec = X.getrow(i)
    d = dist_raw(post_vec,new_post_vec)

    print("==Post %i with dist = %.2f     :  %s" % (i,d,contents[i]))

    if d<best_dist:
        best_dist = d
        best_i
# print("Best post is %i,dist = %.2f" %(best_i, best_dist))
# print('-->', new_post)
# print('----->', contents[best_i])

def tfidf(t,d,D):
    tf = float(d.count(t)) / sum(d.count(w) for w in set(d))
    idf = sp.log( float(len(D)) / (len([doc for doc in D if t in doc])) )
    return tf, idf

a, abb, abc = ['a'], ['a','b','b'],['a','b','c']

D = [a,abb,abc]
# print(tfidf('a',a,D))
# print(tfidf('b',abb,D))
# print(tfidf('a',abc,D))
# print(tfidf('b',abc,D))
# print(tfidf('c',abc,D))
'''
(1.0, 0.0)
(0.6666666666666666, 0.4054651081081644)
(0.3333333333333333, 0.0)
(0.3333333333333333, 0.4054651081081644)
(0.3333333333333333, 1.0986122886681098)
'''
def tfidf(t,d,D):
    tf = float(d.count(t)) / sum(d.count(w) for w in set(d))
    idf = sp.log( float(len(D)) / (len([doc for doc in D if t in doc])) )
    return tf*idf

from sklearn.feature_extraction.text import TfidfVectorizer
vectorizer = TfidfVectorizer(min_df=1, decode_error='ignore')
contents_tokens = [t.morphs(row) for row in contents]

contents_for_vectorize = []

for content in contents_tokens:
    sentence = ''
    for word in content:
        sentence = sentence + ' ' + word

    contents_for_vectorize.append(sentence)

X = vectorizer.fit_transform(contents_for_vectorize)
num_samples, num_features = X.shape
# print(num_samples)
# print(num_features)
# 4, 20

# vectorizer.get_feature_names()

new_post = ['근처 공원에 메리랑 놀러가고 싶네요.']
new_post_tokens = [t.morphs(row) for row in new_post]

new_post_for_vectorize=[]

for content in new_post_tokens:
    sentence = ''
    for word in content:
        sentence = sentence + ' ' + word
    new_post_for_vectorize.append(sentence)
new_post_for_vectorize
# pprint(new_post_for_vectorize)
#[' 근처 공원 에 메리 랑 놀러 가고 싶네요 .']

best_doc = None
best_dist = 65535
best_i = None
for i in range(0, num_samples):
    post_vec = X.getrow(i)
    d = dist_raw(post_vec,new_post_vec)

    print("==Post %i with dist = %.2f     :  %s" % (i,d,contents[i]))

    if d<best_dist:
        best_dist = d
        best_i = i

print("Best post is %i,dist = %.2f" %(best_i, best_dist))
print('-->', new_post)
print('----->', contents[best_i])
'''
Best post is 1,dist = 1.39
--> ['근처 공원에 메리랑 놀러가고 싶네요.']
-----> 메리는 공원에서 산책하고 노는 것을 싫어해요
'''

''' 8.8 여자 친구 선물 고르기 '''
plt.rcParams['axes.unicode_minus'] = False

tmp1 = 'https://search.naver.com/search.naver?where=kin'
html = tmp1 + '&sm=tab_jum&ie=utf8&query={key_word}&start={num}'

param = {'where':'post',
         'query':'여친선물',
         'start':'1'
}
headers ={'User-Agent' : 'Mozilla/5.0'}

response = requests.get(html, params=param, headers=headers)
print(response)

# <Response [200]>
soup = BeautifulSoup(response.text, "html.parser")
# pprint(soup)

tmp = soup.find_all('div')
# pprint(tmp)
tmp_list = []
for line in tmp:
    tmp_list.append(line.text)
# pprint(tmp_list)
# 먼가 많음 한번더 확인
present_candi_text = []

for n in tqdm(range(1, 1000, 10)):
    response = requests.get(html, params=param, headers=headers)
    soup = BeautifulSoup(response.text, "html.parser")
    tmp = soup.find_all('div')
    for line in tmp:
        present_candi_text.append(line.text)
    time.sleep(0.5)

print(present_candi_text)
pprint(len(present_candi_text))
# 22700

present_text = ''
for each_line in present_candi_text[:10000]:
    present_text = present_text + each_line + '\n'

tokens_ko = t.morphs(present_text)
# tokens_ko
# pprint(tokens_ko)

ko = nltk.Text(tokens_ko, name='여자 친구 선물')
print(len(ko.tokens))
print(len(set(ko.tokens)))
pprint(ko.vocab().most_common(100)) # 결과 안뜸...
pprint(ko.similar('여자친구'))
# No matches
# 불용어 지정!   ####  
stop_words = ['.','가','요','...','을','수','에','질문','제','를','이','도',
              '좋','1','는','로','으로','2','것','은','다',',','니다','대','들',
              '2017','들','..','의','때','겠','고','게','네요','한','일','할',
              '10','?','하는','06','주','려고','인데','거','좀','는데','~','ㅎㅎ',
              '하나','이상','20','뭐','까','있는','잘','습니다','다면','했','주려',
              '지','있','못','후','중','줄','6','과','어떤','기본','!!',
              '단어','선물해','라고','중요한','합','가요','....','보이','네','무지']
tokens_ko = [each_word for each_word in tokens_ko if each_word not in stop_words]
ko = nltk.Text(tokens_ko, name='여자 친구 선물')
ko.vocab().most_common(50) # 모스트 커먼 숫자 조정
# pprint(ko.vocab().most_common(50))
plt.figure(figsize=(15,6))
ko.plot(50)
plt.show()

# from wordcloud import WordCloud,STOPWORDS
# from PIL import Image
#
# data = ko.vocab().most_commom(300)
#
# wordcloud = WordCloud(font_path='c:/Windows/Fonts/malgun.ttf',
#                       relative_scaling=0.2,
#                       # stopwords=STOPWORDS,
#                       background_color='white',
#                       ).generate_from_frequencies(dict(data))
# # plt.figure(figsize=(16,8))
# # plt.imshow(wordcloud)
# # plt.axis("off")
# # plt.show()
#
# mask = np.array(Image.open())
#
#





