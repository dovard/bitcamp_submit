from django.urls import path
from . import views
from home.dash_apps.finished_apps import simpleexample

urlpatterns = [
    path('', views.home, name='home'),
    path('test11', views.test11, name='test11'),
    path('test22', views.test22, name='test22')
]