from keras.preprocessing.sequence import TimeseriesGenerator


from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import LSTM, Dense
import plotly.graph_objects as go
import pandas as pd #주가 데이터
import numpy as np


# import matplotlib.pyplot as plt #시각화
# import seaborn as sns

import FinanceDataReader as fdr
# from fbprophet import Prophet
# from fbprophet.plot import plot_plotly, plot_components_plotly
import plotly.graph_objs as go

class PredictModel:
    def __init__(self):
        print('init')

    def start_predict(self, theme, company, modelString, predict_term):

        code = ''
        from_date = '2018-09-01'

        # 여기서 테마, 회사 를 조건으로 종목코드 넣기
        if theme == 'game':
            if company == '넥슨':
                code = '041140'
            if company == '크래프톤':
                code = '259960'
            if company == 'ncSoft':
                code = '036570'

        print(theme, company, modelString)
        df = fdr.DataReader(code, from_date)

        if modelString == 'lstm':
            accur_print = self.lstm(df, predict_term)
        return accur_print    

        # if model == 'prophet':
        #     self.prophet(df)

    def lstm(self, df, predict_term):
        print('실행')
        df.drop(columns=['Open', 'High', 'Low', 'Volume', 'Change'], inplace=True)

        close_data = df['Close'].values
        close_data = close_data.reshape((-1, 1))

        split_percent = 0.80
        split = int(split_percent * len(close_data))

        close_train = close_data[:split]
        close_test = close_data[split:]

        date_train = df.index[:split]
        date_test = df.index[split:]

        print(len(close_train))
        print(len(close_test))

        look_back = 15

        train_generator = TimeseriesGenerator(close_train, close_train, length=look_back, batch_size=10)
        test_generator = TimeseriesGenerator(close_test, close_test, length=look_back, batch_size=1)

        model = Sequential()
        model.add(
            LSTM(10,
                 activation='relu',
                 input_shape=(look_back, 1))
        )
        model.add(Dense(1))
        model.compile(optimizer='adam', loss='mean_squared_error')

        num_epochs = 50
        model.fit_generator(train_generator, epochs=num_epochs, verbose=1)

        prediction = model.predict_generator(test_generator)

        close_train = close_train.reshape((-1))
        close_test = close_test.reshape((-1))
        prediction = prediction.reshape((-1))

        trace1 = go.Scatter(
            x=date_train,
            y=close_train,
            mode='lines',
            name='Data'
        )
        trace2 = go.Scatter(
            x=date_test,
            y=prediction,
            mode='lines',
            name='Prediction'
        )
        trace3 = go.Scatter(
            x=date_test,
            y=close_test,
            mode='lines',
            name='Ground Truth'
        )
        layout = go.Layout(
            title="SS Stock",
            xaxis={'title': "Date"},
            yaxis={'title': "Close"}
        )
        fig = go.Figure(data=[trace1, trace2, trace3], layout=layout)
        # fig.show()

        # 평균절대값백분율오차계산 (MAPE)
        print(np.sum(abs(close_test[look_back:] - prediction) / close_test[look_back:]) / len(close_test))
        accuracy = 100 - (
                    (np.sum(abs(close_test[look_back:] - prediction) / close_test[look_back:]) / len(close_test)) * 100)
        accur_print = '정확도: ' + str(round(accuracy, 2)) + '%'

        close_data = close_data.reshape((-1))

        def predict(num_prediction, model):
            prediction_list = close_data[-look_back:]

            for _ in range(num_prediction):
                x = prediction_list[-look_back:]
                x = x.reshape((1, look_back, 1))
                out = model.predict(x)[0][0]
                prediction_list = np.append(prediction_list, out)
            prediction_list = prediction_list[look_back - 1:]

            return prediction_list

        def predict_dates(num_prediction):
            last_date = df.index.values[-1]
            prediction_dates = pd.date_range(last_date, periods=num_prediction + 1).tolist()
            return prediction_dates


        num_prediction = 20

        if predict_term == '5':
            num_prediction = 5
        if predict_term == '30':
            num_prediction = 30

        forecast = predict(num_prediction, model)
        forecast_dates = predict_dates(num_prediction)

        trace1 = go.Scatter(
            x=date_train,
            y=close_train,
            mode='lines',
            name='Data'
        )
        trace2 = go.Scatter(
            x=date_test,
            y=prediction,
            mode='lines',
            name='Prediction'
        )
        trace3 = go.Scatter(
            x=date_test,
            y=close_test,
            mode='lines',
            name='Ground Truth'
        )
        trace4 = go.Scatter(
            x=forecast_dates,
            y=forecast,
            mode='lines',
            name='Forecast'
        )
        layout = go.Layout(
            title="SS",
            xaxis={'title': "Date"},
            yaxis={'title': "Close"}
        )
        fig = go.Figure(data=[trace1, trace2, trace3, trace4], layout=layout)
        # fig.show()
        fig.write_json('stocktest3.json')
        return accur_print


    # def prophet(self, ss_stock):
    #     plt.figure(figsize=(16, 9))
    #     sns.lineplot(x=ss_stock.index, y="Close", data=ss_stock)
    #     plt.show()
    #     ss_stock['y'] = ss_stock['Close']  # 예측하고싶은거 y-cloumn으로
    #     ss_stock['ds'] = ss_stock.index
    #
    #     ss_stock.head()
    #     m = Prophet()  # ->객체 선언
    #     m.fit(ss_stock)  # - >>>학습끝!!
    #     future = m.make_future_dataframe(periods=365)  # 예측하고 싶은 구간 설정-> 향후 30일 예측
    #     future.tail()  # -> 예측한거 아니고 예측할 Date만 보여줌
    #     forecast = m.predict(future)
    #     forecast.tail()  # ->나중에 그래프 그릴때 column참고해서 그릴거 => 가장 중요한거 yhat!!!!!!
    #     # 요약본
    #
    #     # m=Prophet()  객체선언
    #     # forecast=m.fit(ss_stock).predict(future)     ss_stock훈련,
    #     # fig=m.plot(forecast)
    #     fig = m.plot(forecast)  # 검은색 점들이 실제 데이터 , 파란색 점들이 트렌드, 점없는 끝부분은 예측값
    #     forecast[['ds', 'yhat', 'yhat_lower', 'yhat_upper']].iloc[-40:-20]  # 다 예측값
    #     fig = plot_plotly(m, forecast)
    #     fig