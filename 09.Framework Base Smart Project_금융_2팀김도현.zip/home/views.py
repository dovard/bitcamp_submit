from onlytest.settings import BASE_DIR
from django.shortcuts import render
from plotly.offline import plot
import plotly.graph_objects as go

import os
import json
import pandas as pd

from home.predict_model.model import PredictModel
from home.predict_model.sentiment import SentimentModel

# Create your views here.

def home(request):
    def scatter1():
        # a = os.path.join(BASE_DIR, 'StockCSV.csv')
        # stock = pd.read_csv(a, header=None, skiprows=1)
        # stock_date = stock[0].tolist()
        # stock_close = stock[1].tolist()
    
        # x1 = stock_date
        # y1 = stock_close

        # trace = go.Scatter(
        #     x = x1,
        #     y = y1
        # )
        # layout = dict(
        #     title = 'Simple Graph',
        #     xaxis = {'title': 'Date'},
        #     yaxis = {'title': 'Close'},
        # )
        b = os.path.join(BASE_DIR, 'stocktest.json')
        with open(b) as f:
            data = json.load(f)

        fig = go.Figure(data)
        plot_div = plot(fig, output_type='div', include_plotlyjs=False)
        return plot_div

    def scatter2():
        c = os.path.join(BASE_DIR, 'stocktest2.json')
        with open(c) as f:
            data = json.load(f)

        fig = go.Figure(data)
        plot_div = plot(fig, output_type='div', include_plotlyjs=False)
        return plot_div

    context = {
        'plot1': scatter1(), 'plot2': scatter2()
    }

    return render(request, 'home/welcome.html', context)

def test11(request):
    b = os.path.join(BASE_DIR, 'stocktest.json')
    with open(b) as f:
        data = json.load(f)
    json1 = data

    context = {
        'json1': json1
    }
    return render(request, 'home/test11.html', context)

def test22(request):
    theme = request.GET.get('theme')
    company = request.GET.get('company')
    model_string = request.GET.get('model')
    predict_term = request.GET.get('predictTerm')
    request_status = request.GET.get('requestStatus')

    string = f'{theme}_{company}_{model_string}_{predict_term}.csv'
    print(string)

    if request_status == 'true':
        model = PredictModel()
        accuracy, cost = model.start_predict(theme, company, model_string, predict_term)

        c = os.path.join(BASE_DIR, 'stocktest3.json')
        with open(c) as f:
            data = json.load(f)
        json3 = data

        sentiment = SentimentModel()
        cloud_data, senti_result, senti_accuracy = sentiment.start_sentiment(company)
        
        context = {
            'company_name': company,
            'json3': json3,
            'testState': '1',
            'accuracy': accuracy,
            'cost' : cost,
            'wordcloud': cloud_data,
            'sentiment': {
                'result': senti_result,
                'accuracy': senti_accuracy 
            }            
        }    

        return render(
            request,
            'home/test22.html',
            context
        )
    else:
        return render(request, 'home/test22.html')