from django.shortcuts import render
from .models import Usertbl

def Usertbl_view(request):
    users = Usertbl.objects.all()
    return render(request, 'main.html', {"users" : users})

# Create your views here.
