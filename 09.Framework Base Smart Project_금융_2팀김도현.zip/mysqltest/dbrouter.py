###core/dbrouter.py
##core는 장고 앱 이름
## django-admin startapp djangotest라면, 앱이름은 djangotest이겠죠!
class MultiDBRouter(object): 
        
    def db_for_read(self, model, **hints): 
        if model._meta.app_label == 'mysqltest': 
            return 'mysql' 
        return None 
        
    def db_for_write(self, model, **hints): 
        # if model._meta.app_label == 'mysqltest': 
        return False #'mysql' 
        #return None  
        
    def allow_relation(self, obj1, obj2, **hints): 
        if obj1._meta.app_label == 'mysqltest' or \
            obj2._meta.app_label == 'mysqltest': 
            return True
        return None 
        
    def allow_migrate(self, db, app_label, model_name=None, **hints): 
        if app_label == 'mysqltest':
            return db == 'mysql'
        return None