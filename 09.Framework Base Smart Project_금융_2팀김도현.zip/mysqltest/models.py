from django.db import models


class Buytbl(models.Model):
    num = models.AutoField(primary_key=True)
    userid = models.ForeignKey('Usertbl', models.DO_NOTHING, db_column='userID')  # Field name made lowercase.
    prodname = models.CharField(db_column='prodName', max_length=6)  # Field name made lowercase.
    groupname = models.CharField(db_column='groupName', max_length=4, blank=True, null=True)  # Field name made lowercase.
    price = models.IntegerField()
    amount = models.SmallIntegerField()

    class Meta:
        managed = False
        #app_label = 'mysql'
        db_table = 'buytbl'


class Usertbl(models.Model):
    userid = models.CharField(db_column='userID', primary_key=True, max_length=8)  # Field name made lowercase.
    name = models.CharField(max_length=10)
    birthyear = models.IntegerField(db_column='birthYear')  # Field name made lowercase.
    addr = models.CharField(max_length=2)
    mobile1 = models.CharField(max_length=3, blank=True, null=True)
    mobile2 = models.CharField(max_length=8, blank=True, null=True)
    height = models.SmallIntegerField(blank=True, null=True)
    mdate = models.DateField(db_column='mDate', blank=True, null=True)  # Field name made lowercase.

    class Meta:
        managed = False
        #app_label = 'mysql'
        db_table = 'usertbl'


class CompanyInfo(models.Model):
    code = models.CharField(primary_key=True, max_length=20)
    company = models.CharField(max_length=40, blank=True, null=True)
    last_update = models.DateField(blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'company_info'